/* popup-script.js */
document.querySelector('#login')
.addEventListener('click', function () {
  chrome.runtime.sendMessage({ message: 'get_auth_token' });
});

document.querySelector('#log_off')
.addEventListener('click', function () {
  chrome.runtime.sendMessage({ message: 'log_off' });
});
